import random
import sys
import time
import json
import requests

key_word=\
[
    "False",
    "None",
    "True",
    "and",
    "as",
    "assert",
    "break",
    "class",
    "continue",
    "def",
    "del",
    "elif",
    "else",
    "except",
    "finally",
    "for",
    "from",
    "global",
    "if",
    "import",
    "in",
    "is",
    "lambda",
    "nonlocal",
    "not",
    "or",
    "pass",
    "raise",
    "return",
    "try",
    "while",
    "with",
    "yield"
]
def_key_word=\
[
    "abs",
    "all",
    "any",
    "basestring",
    "bin",
    "bool",
    "bytearray",
    "divmod",
    "enumerate",
    "eval",
    "execfile",
    "exec",
    "file",
    "filter",
    "float",
    "input",
    "int",
    "isinstance",
    "issubclass",
    "iter",
    "len",
    "list",
    "open",
    "ord",
    "pow",
    "print",
    "property",
    "range",
    "raw_input",
    "staticmethod",
    "str",
    "sum",
    "super",
    "tuple",
    "type",
    "unichar",
    "Callable",
    "chr",
    "classmethod",
    "cmp",
    "compile",
    "cimplex",
    "delattr",
    "dict",
    "dir",
    "format",
    "frozenset",
    "getattr",
    "globals",
    "hasattr",
    "hash",
    "help",
    "hex",
    "id",
    "locals",
    "long",
    "map",
    "max",
    "memoryview",
    "min",
    "next",
    "object",
    "oct",
    "reduce",
    "reload",
    "repr",
    "reversed",
    "round",
    "set",
    "setattr",
    "slice",
    "sorted",
    "unicode",
    "vars",
    "xrange",
    "zip",
    "import",
    "apply",
    "buffer",
    "coerce",
    "intern",
    "+",
    "+=",
    "-",
    "-=",
    "*",
    "*=",
    "**",
    "/",
    "/=",
    "//",
    "&",
    "&=",
    "|",
    "|="
]
def rand(ma,mi,seed=time.time()):
    random.seed(seed)
    return random.randint(ma,mi)
def chance(num):
    return random.randint(0,100)<=num
def say(txt):
    for i in range(len(txt)):
        cout<<txt[i]
        sys.stdout.flush()
        sleep(0.1)
def printCode(code_input):
    code=code_input.split(" ",-1)
    cout<<"\033[48;2;255;255;255m"
    for i in range(len(code)):
        find_code=0
        for j in range(len(key_word)):
            if code[i]==key_word[j]:
                cout<<"\033[38;2;0;0;255m"<<code[i]
                find_code=1
                break
            else:
                find_code=0
        if not find_code:
            for j in range(len(def_key_word)):
                if code[i]==def_key_word[j]:
                    cout<<"\033[38;2;100;100;100m"<<code[i]
                    find_code=1
                    break
                else:
                    find_code=0
        if not find_code:
            cout<<"\033[38;2;0;0;0m"<<code[i]
        cout<<" "
    cout<<"\033[0m"
def reLang(msg,from_lang="auto-delete",to_lang="en"):
    '''
中文:zh
英语:en
日语:jp
韩语:kor
西班牙语:spa 
法语:fra
泰语:th
阿拉伯语:ara
俄罗斯语:ru 
葡萄牙语:pt
粤语:yue
文言文:wyw
白话文:zh
自动检测:auto
    '''
    s = msg
    headers = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36"}
    post_data = {
        "fromLang": from_lang,
        "text": s,
        "to": to_lang
        }
    
    post_url = "https://cn.bing.com/ttranslatev3?isVertical=1&&IG=69AE79EB80F34E39A33C0574E30DF1FE&IID=translator.5025.1"
    
    res = requests.post(post_url, headers=headers, data=post_data)
    string = res.content.decode()
    return string