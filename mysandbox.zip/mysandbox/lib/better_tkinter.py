from PIL import Image,ImageTk

import tkinter

#img_num=0

#def TkImage(fpath):
#exec(f"""
#def TkImage(fpath):
#    global img{img_num}_png,img_num
#    img_open=Image.open(fpath)
#    img{img_num}_png=ImageTk.PhotoImage(img_open)
#    img_num+=1
#    return img{img_num}_png
#""")
#    img_num+=1
#    return img_png
img_png=None
def TkImage(fpath):
    global img_png
    img_open=Image.open(fpath)
    img_png=ImageTk.PhotoImage(img_open)
    return img_png
