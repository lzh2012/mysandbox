import numpy as np
import random
import time

def rand(m,mm,s):
    random.seed(s)
    return random.randint(mm,m)
pox=[]
poy=[]

for ix in range(20):
    for iy in range(20):
        pox.append(ix)

for ix in range(20):
    for iy in range(20):
        poy.append(iy)

def rn(seed,x):
    random.seed(seed)
    r = random.uniform(-1, x)
    r = (int(str(r)[-1])-5)/5
    return r
def rn2dx(seed,x,y):
    random.seed(seed)
    b = random.uniform(-1, x)
    b2 = random.uniform(-1, y)
    r = (int(str(b/b2)[-1])-5)/5
    return r

def twist(x):
    
    return x**3 * (6 * x**2 - 15 * x + 10)

def dot(x,y,xv,yv):
    
    return x*xv + y*yv

def lerp(y1,y2,w):

    return y1 + (y2 - y1) * w

def noise2d(gx1,gy1,gx2,gy2,gx3,gy3,gx4,gy4,h,l):
    x = []
    y = []
    noise = list()
    for _x in range(l):
        for _y in range(l):
            x.append(_x/l)
            y.append(_y/l)
    x = np.array(x)
    y = np.array(y)
    w = twist(x)
    w2 = twist(y)
    xv2 = x-1
    yv3 = y-1
    d1 = dot(gx1,gy1,x,y)
    d2 = dot(gx2,gy2,xv2,y)
    d3 = dot(gx3,gy3,x,yv3)
    d4 = dot(gx4,gy4,xv2,yv3)
    noise = (lerp(lerp(d1,d2,w),lerp(d3,d4,w),w2)+1)*h/2
#    print(noise)
    return list(noise)

def noise1d(rx1,rx2,h,l):

    noise = list()
    ab = []
    xv1 = []
    xv2 = []
    for _x in range(l):
        x = _x/l
        xv1.append(x)
        xv2.append(x-1)
        ab.append(x)
    ab = np.array(ab)
    xv1 = np.array(xv1)
    xv2 = np.array(xv2)
    w = twist(ab)
    d1 = dot(rx1,1,xv1,1)
    d2 = dot(rx2,1,xv2,1)
    noise = (lerp(d1,d2,w))*h/2
    return list(noise)
