#{
#我:100%
#}版权
import time
import sys
import os

class istream(object):
    def __init__(self, output=None):
        if output is None:
            import sys
            output = sys.stdin
            self.output = output
            self.mark=0
    def __rshift__(self, thing):
        if self.mark==0:
            self._in=input()
        self.i=self._in.split(" ")
        try:
            exec("global "+thing+";"+thing+"=self.i[self.mark]")
        except IndexError:
            self._in=input()
            exec("global "+thing+";"+thing+"=self._in")
        self.mark+=1
        return self
cin=istream()
class IOManipulator(object):
    def __init__(self, function=None):
        self.function = function

    def do(self, output):
        self.function(output)
class ostream(object):
    def __init__(self, output=None):
        if output is None:
            import sys
            output = sys.stdout
            self.output = output
            self.format = '%s'

    def __lshift__(self, thing):
        if isinstance(thing, IOManipulator):
            thing.do(self)
        else:
            self.output.write(self.format % thing)
            self.format = '%s'
        return self
# 处理回车
def do_endle(stream):
    stream.output.write('\n')
    stream.output.flush()
endl = IOManipulator(do_endle)
cout = ostream()
def printf(i,*j):
    f=0
    r=0
    while r <len(i):
        if i[r] !="%":
            cout<<i[r]
        else:
            r+=1
            if i[r] =="%":
                cout<<"%"
            elif i[r] == "d":
                cout<<int(j[f])
                f+=1
            elif i[r] == "s":
                cout<<str(j[f])
                f+=1
            elif i[r] == "f":
                cout<<float(j[f])
                f+=1
            elif i[r] == "c":
                cout<<chr(j[f])
                f+=1
        r+=1

def int_main():
    cout<<"\033[0;32m编译成功\033[0m\n\n"
def _return(n):
    cout<<"\n\n\033[38;2;255;255;0m代码运行结束\033[0m\033[?25l\033[8m"
def usleep(n):
    time.sleep(n/1000000)